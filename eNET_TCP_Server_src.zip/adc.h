#pragma once
#include <pthread.h>
// ADC Streaming-related stuff for eNET-AIO Family hardware


extern volatile bool AdcStreamTerminate;
void *worker_main(void *arg);
extern pthread_t worker_thread;
extern pthread_t AdcLogger_thread;
extern int AdcStreamingConnection;
extern int AdcWorkerThreadID;