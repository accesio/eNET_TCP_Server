#include "apci.h"
#include "apcilib.h"
#include <iostream>
#include "eNET-AIO16-16F.h"
#include "logging.h"
#include "config.h"

__u8 in8(int offset)
{
	__u8 value = 0;
	int status = apci_read8(apci, 0, BAR_REGISTER, offset, &value);
	Trace("in8(" + to_hex<__u8>(static_cast<__u8>(offset)) + ") ? " + to_hex<__u8>(value));
	return status ? -1 : value;
}

__u16 in16(int offset)
{
	__u16 value = 0;
	int status = apci_read16(apci, 0, BAR_REGISTER, offset, &value);
	Trace("in16(" + to_hex<__u8>(static_cast<__u8>(offset)) + ") ? " + to_hex<__u16>(value));
	return status ? -1 : value;
}

__u32 in32(int offset)
{
	__u32 value = 0;
	int status = apci_read32(apci, 0, BAR_REGISTER, offset, &value);
	Trace("in32(" + to_hex<__u8>(static_cast<__u8>(offset)) + ") ? " + to_hex<__u32>(value));

	return status ? -1 : value;
}

__u32 in(int offset)
{
	switch (widthFromOffset(offset))
	{
	case 8:
		return in8(offset);
	case 16:
		return in16(offset);
	case 32:
		return in32(offset);
	default:
		return -1;
		break;
	}
}

TError out8(int offset, __u8 value)
{
	int status = apci_write8(apci, 0, BAR_REGISTER, offset, value);
	Trace("out8(" + to_hex<__u8>(static_cast<__u8>(offset)) + ", " + to_hex<__u8>(value) + ")" );
	return status;
}

TError out16(int offset, __u16 value)
{
	int status = apci_write16(apci, 0, BAR_REGISTER, offset, value);
	Trace("out16(" + to_hex<__u8>(static_cast<__u8>(offset)) + ", " + to_hex<__u16>(value) + ")" );
	return status;
}

TError out32(int offset, __u32 value)
{
	int status = apci_write32(apci, 0, BAR_REGISTER, offset, value);
	Trace("out32(" + to_hex<__u8>(static_cast<__u8>(offset)) + ", " + to_hex<__u32>(value) + ")" );
	return status;
}

static TError WaitBeforeRegisterWrite(int offset)
{
	switch (offset)
	{
	case ofsDac:
		return WaitUntilRegisterBitIsLow(ofsDacSpiBusy, bmDacSpiBusy);

	case ofsDioDirections:
	case ofsDioOutputs:
		return WaitUntilRegisterBitIsLow(ofsDioSpiBusy, bmDioSpiBusy);

	default:
		return ERR_SUCCESS;
	}
}

TError out(int offset, __u32 value)
{
	TError waitStatus = WaitBeforeRegisterWrite(offset);
	if (waitStatus != ERR_SUCCESS)
		return waitStatus;

	switch (widthFromOffset(offset))
	{
	case 8:{
			TError status = out8(offset, static_cast<__u8>(value));
			if (offset == ofsReset && (value & (bmResetEverything | bmResetAdc)))
				ApplyAdcCalConfig();
			return status;
		}
	case 16:
		return out16(offset, static_cast<__u16>(value));
	case 32:
		return out32(offset, value);
	default:
		return -1;
	}
}

int apciGetDevices() { return apci_get_devices(apci); }

int apciGetDeviceInfo(unsigned int *deviceID, unsigned long bars[6]) { return apci_get_device_info(apci, 0, deviceID, bars); }

int apciWaitForIRQ() { return apci_wait_for_irq(apci, 0); }

int apciCancelWaitForIRQ() { return apci_cancel_irq(apci, 0); }

int apciDmaTransferSize(__u8 slots, size_t size) { return apci_dma_transfer_size(apci, 0, slots, size); }

int apciDmaDataReady(int *start_index, int *slots, int *data_discarded) { return apci_dma_data_ready(apci, 0, start_index, slots, data_discarded); }

int apciDmaDataDone(int slots) { return apci_dma_data_done(apci, 0, slots); }

int apciDmaStart() { return apci_start_dma(apci); }

// int apci_writebuf8(int fd, unsigned long device_index, int bar, int bar_offset, unsigned int mmap_offset, int length);
// int apci_writebuf16(int fd, unsigned long device_index, int bar, int bar_offset, unsigned int mmap_offset, int length);
// int apci_writebuf32(int fd, unsigned long device_index, int bar, int bar_offset, unsigned int mmap_offset, int length);

// int apci_dac_buffer_size (int fd, unsigned long size);
